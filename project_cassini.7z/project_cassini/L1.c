stk.v.10.0
WrittenBy    STK_v10.1.0

BEGIN Chain

Name  L1
BEGIN Definition

   Type        Chain
   Operator    Or
   Order       1
   Recompute   Yes
   IntervalType    0
   ComputeIntervalStart    0.000000
   ComputeIntervalStop     86400.000000
    ComputeIntervalPtr
	BEGIN	EVENTINTERVAL
			BEGIN Interval
				Start	13 May 2017 10:00:00.000000000
				Stop	14 May 2017 10:00:00.000000000
			END Interval
			IntervalState	Explicit
	END	EVENTINTERVAL

   UseSaveIntervalFile    No
   UseMinAngle     No
   UseMaxAngle     No
   UseMinLinkTime     No
   LTDelayCriterion    2.000000
   TimeConvergence     5.000000e-003
   AbsValueConvergence 1.000000e-014
   RelValueConvergence 1.000000e-008
   MaxTimeStep         360.000000
   MinTimeStep         1.000000e-002
   UseLightTimeDelay   Yes
    DetectEventsUsingSamplesOnly No
    Object  Satellite/Satellite1/Transmitter/L1
    Object  Facility/DSS_15_Goldstone_STDN_DS15/Sensor/Sensor2/Receiver/R1
   SaveMode    1
BEGIN StrandAccesses

  Strand    Satellite/Satellite1/Transmitter/L1 To Facility/DSS_15_Goldstone_STDN_DS15/Sensor/Sensor2/Receiver/R1
    Start    0
    Stop     13423.623736704265
    Start    64504.943528999996
    Stop     81812.999322999996
END StrandAccesses

   UseLoadIntervalFile    No

END Definition

BEGIN Extensions
    
    BEGIN Graphics

BEGIN Attributes

StaticColor					#00ffff
AnimationColor					#ff00ff
AnimationLineWidth					2.000000
StaticLineWidth					3.000000

END Attributes

BEGIN Graphics
    ShowGfx                On
    ShowStatic             Off
    ShowAnimationHighlight On
    ShowAnimationLine      On
    ShowLinkDirection      Off
END Graphics
    END Graphics
    
    BEGIN ADFFileData
    END ADFFileData
    
    BEGIN Desc
        ShortText    0

        LongText    0

    END Desc
    
    BEGIN Crdn
    END Crdn
    
    BEGIN VO
    END VO

END Extensions

END Chain

